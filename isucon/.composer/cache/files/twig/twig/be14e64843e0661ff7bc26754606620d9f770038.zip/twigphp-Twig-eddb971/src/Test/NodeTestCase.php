<?php

namespace Twig\Test;

class_exists('Twig_Test_NodeTestCase');

if (\false) {
    class NodeTestCase extends \Twig_Test_NodeTestCase
    {
    }
}
