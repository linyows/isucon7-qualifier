<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_In');

if (\false) {
    class InBinary extends \Twig_Node_Expression_Binary_In
    {
    }
}
