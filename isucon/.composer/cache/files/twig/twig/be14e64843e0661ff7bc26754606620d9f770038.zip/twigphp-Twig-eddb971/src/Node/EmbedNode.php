<?php

namespace Twig\Node;

class_exists('Twig_Node_Embed');

if (\false) {
    class EmbedNode extends \Twig_Node_Embed
    {
    }
}
