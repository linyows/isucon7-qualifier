Deprecated Features
===================

This document lists deprecated features in Twig 2.x. Deprecated features are
kept for backward compatibility and removed in the next major release (a
feature that was deprecated in Twig 2.x is removed in Twig 3.0).

Final Classes
-------------

The following classes are marked as ``@final`` in Twig 2 and will be final in
3.0:

 * ``Twig_Node_Module``
 * ``Twig_Filter``
 * ``Twig_Function``
 * ``Twig_Test``
 * ``Twig_Profiler_Profile``
