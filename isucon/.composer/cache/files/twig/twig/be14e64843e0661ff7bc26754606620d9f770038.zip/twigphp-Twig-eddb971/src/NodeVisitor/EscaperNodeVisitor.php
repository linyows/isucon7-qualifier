<?php

namespace Twig\NodeVisitor;

class_exists('Twig_NodeVisitor_Escaper');

if (\false) {
    class EscaperNodeVisitor extends \Twig_NodeVisitor_Escaper
    {
    }
}
