<?php

namespace Twig\Node\Expression;

class_exists('Twig_Node_Expression_Parent');

if (\false) {
    class ParentExpression extends \Twig_Node_Expression_Parent
    {
    }
}
