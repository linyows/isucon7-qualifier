<?php

namespace Twig\Node\Expression;

class_exists('Twig_Node_Expression_BlockReference');

if (\false) {
    class BlockReferenceExpression extends \Twig_Node_Expression_BlockReference
    {
    }
}
