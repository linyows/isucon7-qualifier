<?php

namespace Twig\Node\Expression;

class_exists('Twig_Node_Expression_Name');

if (\false) {
    class NameExpression extends \Twig_Node_Expression_Name
    {
    }
}
