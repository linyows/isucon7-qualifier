<?php

namespace Twig;

class_exists('Twig_SimpleFunction');

if (\false) {
    class TwigFunction extends \Twig_SimpleFunction
    {
    }
}
