<?php

namespace Twig\Node;

class_exists('Twig_Node_With');

if (\false) {
    class WithNode extends \Twig_Node_With
    {
    }
}
